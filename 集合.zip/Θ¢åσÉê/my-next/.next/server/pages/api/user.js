/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(function() {
var exports = {};
exports.id = "pages/api/user";
exports.ids = ["pages/api/user"];
exports.modules = {

/***/ "./pages/api/user.js":
/*!***************************!*\
  !*** ./pages/api/user.js ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ((req, res) => {\n  res.send({\n    name: '吴签',\n    charge: '强奸罪'\n  });\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1uZXh0Ly4vcGFnZXMvYXBpL3VzZXIuanM/MmFiYiJdLCJuYW1lcyI6WyJyZXEiLCJyZXMiLCJzZW5kIiwibmFtZSIsImNoYXJnZSJdLCJtYXBwaW5ncyI6IjtBQUFBLCtEQUFlLENBQUNBLEdBQUQsRUFBTUMsR0FBTixLQUFjO0FBQzNCQSxLQUFHLENBQUNDLElBQUosQ0FBUztBQUFFQyxRQUFJLEVBQUUsSUFBUjtBQUFjQyxVQUFNLEVBQUU7QUFBdEIsR0FBVDtBQUNELENBRkQiLCJmaWxlIjoiLi9wYWdlcy9hcGkvdXNlci5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IChyZXEsIHJlcykgPT4ge1xuICByZXMuc2VuZCh7IG5hbWU6ICflkLTnrb4nLCBjaGFyZ2U6ICflvLrlpbjnvaonIH0pXG59XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/api/user.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/user.js"));
module.exports = __webpack_exports__;

})();