import Link from 'next/link'
import Head from 'next/head'
// 通过import引入外部样式文件
import style from '../styles/index.module.css'

export default function Home() {
  return (
    <>
      <Head>
        <title>Home</title>
      </Head>
      <p>Home内容</p>
      <Link href='/list'>
        {/* 直接使用引入的样式文件设置类名 */}
        <a className={style.a}>跳转到list</a>
      </Link>
    </>
  )
}
