export default (req, res) => {
  res.send({ name: '吴签', charge: '强奸罪' })
}
