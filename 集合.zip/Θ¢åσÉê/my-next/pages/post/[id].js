import { useRouter } from 'next/router'

// 用于获取关于此id全部的路由参数
export async function getStaticPaths() {
  // 注意：这里id必须使用字符串，否则会报错
  return {
    // 全部可能的路由信息，这里直接写死，工作中可以从接口获取
    paths: [{ params: { id: '1' } }, { params: { id: '2' } }],
    // 为true时，访问非1和2会尝试进行静态生成，否则直接显示404页面
    fallback: true,
  }
}

// 上面paths会被遍历，每次遍历都会调用这个方法进行静态生成
// params即为路由信息
export async function getStaticProps({ params }) {
  const id = params.id
  // 创建data接收数据
  let data
  // 这里使用switch写死数据，工作中可以根据路由信息进行异步请求数据等工作
  switch (id) {
    case '1':
      data = { id: '1', title: '第一篇文章标题' }
      break
    case '2':
      data = { id: '2', title: '第二篇文章标题' }
      break
    // id为3是不在上面范围内的
    case '3':
      data = { id: '3', title: '第三篇文章标题' }
      break
    default:
      data = {}
  }
  // 最终把数据返回出去
  return {
    props: {
      data,
    },
  }
}

// 组件接收数据并使用数据
function Post(props) {
  const router = useRouter()
  // 判断是否正在静态生成
  if (router.isFallback) return <div>正在静态生成</div>
  return (
    <>
      <p>{props.data.id}</p>
      <p>{props.data.title}</p>
    </>
  )
}

export default Post
