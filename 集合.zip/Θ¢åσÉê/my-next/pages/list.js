import React from 'react'
// 引入Head修改/定制元数据
import Head from 'next/head'
// Node读取文件API
import { readFile } from 'fs'
// 将读取文件API进行包装，让她返回Promis对象
import { promisify } from 'util'
// 路径拼接API
import { join } from 'path'

// 包装读取API
const read = promisify(readFile)

// 直接接收到静态构建所需数据
function List(props) {
  return (
    <>
      {/* 元数据 */}
      <Head>
        {/* 设置自己的页面的title */}
        <title>List</title>
      </Head>
      <div>List内容</div>
      {/* 直接使用数据 */}
      <p>{props.data}</p>
    </>
  )
}

export default List

// 进行服务器端渲染
export async function getServerSideProps(context) {
  // 我们在这里直接读取pages/_app.js文件内容，实际工作中也可以是一个接口请求
  const data = await read(join(process.cwd(), 'pages', '_app.js'), 'utf-8')
  // 打印看一下
  console.log(data, context.query)
  // 最终返回出去
  return {
    // 这个props可以在list组件上直接使用
    props: {
      data,
    },
  }
}
