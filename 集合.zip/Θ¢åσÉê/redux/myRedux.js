// 模拟 cerateStore 方法
function cerateStore(reducer, preloadedState, enhancer) {
  // 直接判断 reducer 是否为函数
  if (typeof reducer !== 'function') throw new Error('reducer必须是一个对象')
  // 判断是否传入了 enhancer
  if (typeof enhancer !== 'undefined') {
    // 传入了 enhancer 判断是否为函数
    if (typeof enhancer !== 'function')
      throw new Error('enhancer必须是一个函数')
    // 为函数调用函数并将 cerateStore 作为参数传递进去
    // 函数会返回一个函数，返回的函数立即被调用
    // 把 reducer 和 preloadedState 作为参数传入新函数
    return enhancer(cerateStore)(reducer, preloadedState)
  }
  // 获取初始状态
  let data = preloadedState
  // 订阅者
  let listeners = []
  // 获取状态方法
  function getState() {
    // 直接返回状态
    return data
  }
  // 指令触发方法
  function dispatch(action) {
    // 调用函数判断是否为对象
    if (!isPlainObject(action)) throw new Error('参数必须是一个对象')
    // 判断是否含有type属性
    if (typeof action.type === 'undefined') throw new Error('需要传入type属性')
    // 调用参数返回结果
    data = reducer(data, action)
    // 遍历订阅者触发订阅者
    for (const listen of listeners) {
      listen()
    }
  }
  // 添加订阅者方法
  function subscribe(cb) {
    // cb 为订阅者要触发的回调函数
    listeners.push(cb)
  }
  // 返回三个方法组成的对象
  return { getState, dispatch, subscribe }
}

// 判断是否为非空对象
function isPlainObject(obj) {
  // 排除出数组外其他情况
  if (typeof obj !== 'object' || obj === null) return false
  // 根据顶层原型对象和自己原型对象判断
  let proto = obj
  while (Object.getPrototypeOf(proto) != null) {
    proto = Object.getPrototypeOf(proto)
  }
  return proto === Object.getPrototypeOf(obj)
}

// 中间件方法，使用 ...将多个参数合并为一个数组
function applyMiddleware(...wares) {
  // 和 Enhancer 相同，上来依旧需要创建基本的 store
  return function (cerateStore) {
    return function (reducer, preloadedState) {
      // 创建 store - 基本
      let store = cerateStore(reducer, preloadedState)
      // 创建阉割版 store 用于带入中间件
      let middlewareAPI = {
        getState: store.getState,
        dispatch: store.dispatch,
      }
      // 执行所有中间件最外层函数，返回数组，该数组包含的事中间件外层返回的函数
      const chain = wares.map(ware => ware(middlewareAPI))
      // 遍历上面数组，执行中间件的第二层函数（解构），传递dispatch，最终返回
      const dispatch = compose(...chain)(store.dispatch)
      // 返回store，并替换dispatch
      return {
        ...store,
        dispatch,
      }
    }
  }
}

// 中间件第二层函数执行
function compose() {
  // 接受参数并由类数组转换为数组
  const funcs = [...arguments]
  // 返回函数，因为要使用 store.dispatch，这里的dispatch就是中间件里面的next参数
  return function (dispatch) {
    // 倒过来执行函数，因为前一个中间件需要使用后一个中间件返回的第三层函数
    for (let i = funcs.length - 1; i >= 0; i--) {
      // 修改参数为后面中间件的第三层函数
      dispatch = funcs[i](dispatch)
    }
    // 直接返回第一个中间件第二层函数
    return dispatch
  }
}

// bindActionCreators 处理 action
// 参数1: action合集
// 参数2: dispatch
function bindActionCreators(arr, diapatch) {
  // 创建一个空对象
  const actions = {}
  // 遍历 action
  for (let key in arr) {
    // 给对象添加属性，对应 action
    actions[key] = function () {
      // 注意这里使用action返回值
      diapatch(arr[key]())
    }
  }
  // 直接返回处理后的 action
  return actions
}

// 合并reducer方法
function combineReducers(obj) {
  // 获取全部属性名
  const keys = Object.keys(obj)
  // 判断导入的reducer是不是都是函数，否则报错
  for (let i = 0; i < keys.length; i++) {
    if (typeof obj[keys[i]] !== 'function')
      throw new Error('reducer必须是一个函数')
  }
  // 返回一个函数，因为store创建时的reducer也必须是一个函数
  return function (state, action) {
    // 创建一个新的state
    const newState = {}
    // 遍历全部传入的 reducer，执行并传递给新的state中
    for (let i = 0; i < keys.length; i++) {
      newState[keys[i]] = obj[keys[i]](state[keys[i]], action)
    }
    // 直接导出新的state作为reducer返回值
    return newState
  }
}
