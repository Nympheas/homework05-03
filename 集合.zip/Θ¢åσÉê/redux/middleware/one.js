// 中间件1
// 参数store：阉割版store，只包括 getState 和 dispatch
// 参数next：下一个中间件，如果当前是最后一个中间件，则 next 就是 dispatch
// 参数action：就是触发的 action
function one(store) {
  return function (next) {
    return function (action) {
      console.log('one中间件执行了')
      next(action)
    }
  }
}
