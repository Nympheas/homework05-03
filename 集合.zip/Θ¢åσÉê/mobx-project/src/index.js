import { Provider } from 'mobx-react'
import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import counter from './stores/countStore'

ReactDOM.render(
  // 使用 Provider 将数据传递下去
  <Provider counter={counter}>
    <App />
  </Provider>,
  document.getElementById('root')
)
