import { inject, observer } from 'mobx-react'
import React, { Component } from 'react'

// 接收状态
@inject('counter')
// 设置观察模式，当状态变化自动更新
@observer
// 组件
class App extends Component {
  render() {
    // 解构获取状态
    const { counter } = this.props
    return (
      <div>
        {/* 文本框，用来输入用户名 */}
        <input
          type='text'
          value={counter.userName}
          onChange={e => counter.changeValue(e.target.value)}
        />
      </div>
    )
  }
}

export default App
