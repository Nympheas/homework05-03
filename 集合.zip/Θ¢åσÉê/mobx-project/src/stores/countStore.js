import { action, autorun, configure, observable } from 'mobx'

// 配置mobx，开启严格模式
configure({ enforceActions: 'observed' })

// 创建store
class CountStore {
  constructor() {
    // autorun要写在constructor中
    // 参数1:执行方法，参数2:配置参数
    autorun(
      () => {
        try {
          // 引入判断方法判断当前用户名是否已存在
          UserNameDistinguish(this.userName)
          // 用户名不存在显示可用
          console.log('用户名可用')
        } catch (e) {
          // 用户名存在报错
          console.log(e.message)
        }
      },
      // 设置延时检测时间2s
      { delay: 2000 }
    )
  }
  @observable userName = ''

  // 修改用户名action
  @action.bound changeValue(value) {
    this.userName = value
  }
}
// 创建实例
const counter = new CountStore()

// 判断用户名是否存在的函数
function UserNameDistinguish(value) {
  return new Promise((resolve, reject) => {
    // 判断用户名
    if (value === 'admin') {
      reject('用户名已存在')
    } else {
      resolve()
    }
  })
}
// 直接导出实例
export default counter
